package com.xianfeng.assist;

/**
 * Created by xianfeng on 16/6/30.
 */
public class NFC4442Message {

    public static final int MESSAGE_READ = 0;
    public static final int MESSAGE_WRITE = 1;
    public static final int MESSAGE_UI = 2;
    public static final int MESSAGE_WRITEDATA = 3;
    public static final int MESSAGE_ERROR = 4;
    public static final int MESSAGE_SOCKET = 5;

    public static final String HOST_IP = "115.236.0.2";
    public static final String HOST_PORT = "8040";

}
